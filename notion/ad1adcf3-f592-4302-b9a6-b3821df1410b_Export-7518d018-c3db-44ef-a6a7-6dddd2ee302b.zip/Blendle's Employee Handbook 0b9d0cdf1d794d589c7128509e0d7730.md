# Blendle's Employee Handbook

This is a living document with everything we've learned working with people while running a startup. And, of course, we continue to learn. Therefore it's a document that will continue to change. 

**Everything related to working at Blendle and the people of Blendle, made public.**

These are the lessons from three years of working with the people of Blendle. It contains everything from [how our leaders lead](https://www.notion.so/ecfb7e647136468a9a0a32f1771a8f52?pvs=21) to [how we increase salaries](https://www.notion.so/Salary-Review-e11b6161c6d34f5c9568bb3e83ed96b6?pvs=21), from [how we hire](https://www.notion.so/Hiring-451bbcfe8d9b49438c0633326bb7af0a?pvs=21) and [fire](https://www.notion.so/Firing-5567687a2000496b8412e53cd58eed9d?pvs=21) to [how we think people should give each other feedback](https://www.notion.so/Our-Feedback-Process-eb64f1de796b4350aeab3bc068e3801f?pvs=21) — and much more.

We've made this document public because we want to learn from you. We're very much interested in your feedback (including weeding out typo's and Dunglish ;)). Email us at hr@blendle.com. If you're starting your own company or if you're curious as to how we do things at Blendle, we hope that our employee handbook inspires you.

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).

## Blendle general

*Information gap closing in 3... 2... 1...*

---

[To Do/Read in your first week](https://www.notion.so/To-Do-Read-in-your-first-week-6c3fdbeeb6a0406895b45ffb86f8c3be?pvs=21)

[History](https://www.notion.so/History-2ddafd10e9f0488eae03e7f12ed02511?pvs=21)

[DNA & culture](https://www.notion.so/DNA-culture-3b97dfc959ed49a2865fde6ef0431081?pvs=21)

[General & practical ](https://www.notion.so/General-practical-ed6e48b4e4fc4c569cc8d9d0df36a69a?pvs=21)

## People operations

*You can tell a company's DNA by looking at how they deal with the practical stuff.*  

---

[Office](https://www.notion.so/Office-65350c0faaf346f5ab666e2f1cfea0fc?pvs=21)

[Time off: holidays and national holidays](https://www.notion.so/Time-off-holidays-and-national-holidays-fab512c1f67f4158b6d927b80c7c97d5?pvs=21)

[Calling in sick/better](https://www.notion.so/Calling-in-sick-better-c8d590cf3338464aaed8a0d978571408?pvs=21)

[Perks and benefits](https://www.notion.so/Perks-and-benefits-27da1aeb7ec542259be7da7c8af6660b?pvs=21)

[Travel costs and reimbursements](https://www.notion.so/Travel-costs-and-reimbursements-9a2e9376cceb45e5bc047c7761617f06?pvs=21)

[Parenthood](https://www.notion.so/Parenthood-95a0927697f34610b865bf6dd7441d30?pvs=21)

## People topics

*Themes we care about.*

---

[Blendle Social Code](https://www.notion.so/Blendle-Social-Code-c710f0cfcf73464fbae26ec63a035e5f?pvs=21)

[Diversity and inclusion](https://www.notion.so/Diversity-and-inclusion-eb49c21938134f32bbb7f9006014b97f?pvs=21)

[#letstalkaboutstress](https://www.notion.so/letstalkaboutstress-e4ac45d3df5242b382ccce4a5e6f47bf?pvs=21)

## Feedback and development

*The number 1 reason for people to work at Blendle is growth and learning from smart people.*

---

[Your 1st month ](https://www.notion.so/Your-1st-month-ea38e273a9e2456abf6e1c76291b8263?pvs=21)

[Goals](https://www.notion.so/Goals-9e01a3c71a654bf69f55de47df3edfd9?pvs=21)

[Feedback cycle](https://www.notion.so/Feedback-cycle-3e4882cc8a634643b447115cd9701109?pvs=21)

[The Matrix™ (job profiles)](https://www.notion.so/The-Matrix-job-profiles-5f83db71f05943e4bcfeaa2ea4ccc9ae?pvs=21)

[Blendle library](https://www.notion.so/Blendle-library-51eff1c2818e42a7b5a91d878f2071b0?pvs=21)

## **Hiring**

*The coolest and most impactful thing when done right.*

---

[Rating systems](https://www.notion.so/Rating-systems-345eba1024ae4b0db5fbb261a0a742c1?pvs=21)

[Getting people in (branding&sourcing)](https://www.notion.so/Getting-people-in-branding-sourcing-44f0f9b0447a40d797bbd976565608dd?pvs=21)

[Highly Skilled Migrants and relocation](https://www.notion.so/Highly-Skilled-Migrants-and-relocation-4c987b9d735244daac4a45980531be6d?pvs=21)

## How to lead at Blendle

*Here are some tips and tools to help you become a great leader.*

---

[How to lead at Blendle ](https://www.notion.so/How-to-lead-at-Blendle-d57a06b14c8545bfb6e87058a461bea6?pvs=21)

[Your check-list](https://www.notion.so/Your-check-list-82e7ab840d5445449c2ab96a244240d1?pvs=21)

[Leading Feedback ](https://www.notion.so/Leading-Feedback-a02af3a1ceb54d499d0048a5fa3bbd8b?pvs=21)

[Salary talks](https://www.notion.so/Salary-talks-4085f5e989df4f16b83ef34ac965adaa?pvs=21)

[Hiring ](https://www.notion.so/Hiring-7ad38a3493ba4a8fa2c00613acedd03d?pvs=21)

[Firing](https://www.notion.so/Firing-314c72df77224d1c98b39f6defe9daae?pvs=21)

[Party and study budget](https://www.notion.so/Party-and-study-budget-df87be0face54cd2a48b5883a2df67f9?pvs=21)

[Holidays](https://www.notion.so/Holidays-af8806b9bc7c415980ea082d9b0c6ca3?pvs=21)

[Sickness absence](https://www.notion.so/Sickness-absence-cb077bdb25684ff684abd5f8e95535a0?pvs=21)

[Personal User Guide](https://www.notion.so/Personal-User-Guide-2b9094c5d78b4617aef3f071037a4e4f?pvs=21)

[Soft shizzle](https://www.notion.so/Soft-shizzle-fc5cf7b5cb9d447b843c5e5efc33c786?pvs=21)

## About this document

---

*Lessons from three years of HR*

[About this document and the author](https://www.notion.so/About-this-document-and-the-author-ca326ab6ad8b4c50b885ff75adb632d0?pvs=21)