# #letstalkaboutstress

Let’s talk about stress. Too much stress. 

We know this can be a topic.

So let’s get this conversation going. 

[Intro: two things you should know](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/Intro%20two%20things%20you%20should%20know%207e05b16a59444cea895b1b58798b6aa2.md)

[What is stress](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/What%20is%20stress%208fea3641c4f1495a8cadede63c58d673.md)

[When is there too much stress?](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/When%20is%20there%20too%20much%20stress%20a241e14b70654d2eb07d6569673981ec.md)

[What can I do](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/What%20can%20I%20do%201b5f4d28cc894c0284c8a96ae4574abf.md)

[What can Blendle do?](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/What%20can%20Blendle%20do%206771b506a5fa44efab8beb49fa5f87ab.md)

[Good reads](#letstalkaboutstress%20e4ac45d3df5242b382ccce4a5e6f47bf/Good%20reads%202464887570644f17b4dbbad0746e37da.md)

Go to **#letstalkaboutstress** on slack to chat about this topic

# Work at Blendle

---

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).